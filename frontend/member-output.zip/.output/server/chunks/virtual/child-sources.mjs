const sources = {
    "zh-CN": [],
    "zh-TW": [],
    "en-US": []
};

export { sources };
//# sourceMappingURL=child-sources.mjs.map
