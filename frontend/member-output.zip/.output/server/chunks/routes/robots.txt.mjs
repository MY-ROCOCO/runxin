import { d as defineEventHandler, g as getHeader, s as setHeader } from './api/index.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import '@iconify/utils';
import 'consola/core';

const robots_txt = defineEventHandler((event) => {
  const host = getHeader(event, "host");
  const protocol = getHeader(event, "x-forwarded-proto") === "https" || event.node.req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;
  const robots = `User-agent: *
Allow: /

Sitemap: ${baseUrl}/sitemap.xml
`;
  setHeader(event, "Content-Type", "text/plain");
  setHeader(event, "Cache-Control", "public, max-age=3600");
  return robots;
});

export { robots_txt as default };
//# sourceMappingURL=robots.txt.mjs.map
