import { d as defineEventHandler } from './index.mjs';
import { exec } from 'child_process';
import { writeFile } from 'fs/promises';
import path from 'path';
import fsExtra from 'fs-extra';
import AdmZip from 'adm-zip';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import '@iconify/utils';
import 'consola/core';

const triggerUpdate_post = defineEventHandler(async () => {
  const zipUrl = "https://admin.reckonkvm.com/output.zip";
  const projectRoot = path.resolve(process.cwd(), "../../");
  const tempZipPath = path.join(projectRoot, "update-temp.zip");
  const tempExtractDir = path.join(projectRoot, ".temp");
  const deployDir = path.join(projectRoot, ".output");
  try {
    console.log("\u2705 \u5F53\u524D\u8FD0\u884C\u76EE\u5F55:", process.cwd());
    console.log("\u2705 \u9879\u76EE\u6839\u76EE\u5F55:", projectRoot);
    const res = await fetch(zipUrl);
    if (!res.ok)
      throw new Error(`\u4E0B\u8F7D\u5931\u8D25\uFF1A${res.status} ${res.statusText}`);
    const buffer = Buffer.from(await res.arrayBuffer());
    await writeFile(tempZipPath, buffer);
    console.log("\u2705 \u4E0B\u8F7D\u5B8C\u6210\uFF0C\u5199\u5165\u6587\u4EF6\u6210\u529F");
    await fsExtra.remove(tempExtractDir);
    const zip = new AdmZip(tempZipPath);
    zip.extractAllTo(tempExtractDir, true);
    console.log("\u2705 \u89E3\u538B\u5B8C\u6210");
    const extractedOutputDir = path.join(tempExtractDir, ".output");
    const exists = await fsExtra.pathExists(extractedOutputDir);
    if (!exists)
      throw new Error("\u274C \u538B\u7F29\u5305\u4E2D\u672A\u627E\u5230 .output \u76EE\u5F55\uFF0C\u8BF7\u68C0\u67E5\u7ED3\u6784");
    console.log("\u2705 \u5207\u6362\u5F53\u524D\u8FD0\u884C\u76EE\u5F55\u5230\u9879\u76EE\u6839\u76EE\u5F55:", projectRoot);
    process.chdir(projectRoot);
    const backupDir = path.join(projectRoot, `.output_backup_${Date.now()}`);
    if (await fsExtra.pathExists(deployDir)) {
      await fsExtra.copy(deployDir, backupDir);
      console.log(`\u2705 \u539F\u59CB .output \u76EE\u5F55\u5DF2\u5907\u4EFD\u5230: ${backupDir}`);
    }
    await fsExtra.remove(deployDir);
    await fsExtra.copy(extractedOutputDir, deployDir);
    console.log("\u2705 \u90E8\u7F72\u76EE\u5F55\u66FF\u6362\u5B8C\u6210:", deployDir);
    exec("pm2 restart nuxt-app", (err, stdout, stderr) => {
      if (err) {
        console.error("\u274C PM2 \u91CD\u542F\u5931\u8D25:", stderr);
      } else {
        console.log("\u2705 PM2 \u91CD\u542F\u6210\u529F:", stdout);
      }
    });
    await fsExtra.remove(tempZipPath);
    await fsExtra.remove(tempExtractDir);
    console.log("\u2705 \u4E34\u65F6\u6587\u4EF6\u6E05\u7406\u5B8C\u6210");
    return {
      code: 0,
      message: "\u2705 \u66F4\u65B0\u6210\u529F\uFF0C\u670D\u52A1\u6B63\u5728\u91CD\u542F"
    };
  } catch (error) {
    console.error("\u274C \u66F4\u65B0\u5931\u8D25:", error);
    return {
      code: 1,
      message: "\u66F4\u65B0\u5931\u8D25",
      error: error.message
    };
  }
});

export { triggerUpdate_post as default };
//# sourceMappingURL=triggerUpdate.post.mjs.map
