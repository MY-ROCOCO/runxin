import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node:http';
import 'node:https';
export { Y as default } from './chunks/routes/api/index.mjs';
import 'node:fs';
import 'node:path';
import 'vue';
import 'node:url';
import '@iconify/utils';
import 'consola/core';
//# sourceMappingURL=index.mjs.map
