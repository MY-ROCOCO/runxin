const e=defineEventHandler(e=>{getHeader(e,"cookie");const o=parseCookies(e).i18n_redirected||"zh";e.context.locale=o});export{e as default};
