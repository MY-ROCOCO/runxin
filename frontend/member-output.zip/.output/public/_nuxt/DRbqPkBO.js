import{b8 as o}from"./CGgrnszq.js";const a=(...a)=>r=>{a.forEach(a=>{o(a)?a(r):a.value=r})};export{a as c};
