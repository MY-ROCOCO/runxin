import{a as r}from"./U9qkErRc.js";function n(){return{generatePassword:function(){return r()}}}export{n as u};
