import"./CGgrnszq.js";const e=""+new URL("agent-banner.BY0gm_3k.png",import.meta.url).href;export{e as i};
