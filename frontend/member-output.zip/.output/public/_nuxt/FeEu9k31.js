import{dA as o}from"./CGgrnszq.js";const s=()=>o().$device;export{s as u};
