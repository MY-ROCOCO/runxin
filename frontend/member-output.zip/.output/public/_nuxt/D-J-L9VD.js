import{d as a,o,a as e}from"./CGgrnszq.js";const s=a({__name:"get-pnone-code-dialog",setup:a=>(a,s)=>(o(),e("div",null,"66666"))});export{s as default};
