import{a0 as o}from"./CGgrnszq.js";const g=o("/login-bg/left_login_2.png");export{g as _};
