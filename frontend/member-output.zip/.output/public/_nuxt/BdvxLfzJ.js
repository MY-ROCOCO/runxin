import{d as a,o as s,a as t}from"./CGgrnszq.js";const e=a({__name:"template2",setup:a=>(a,e)=>(s(),t("div"))});export{e as default};
