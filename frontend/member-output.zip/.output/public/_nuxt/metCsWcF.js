import"./CGgrnszq.js";const e=""+new URL("web-deploy.BsYY94xU.png",import.meta.url).href;export{e as _};
