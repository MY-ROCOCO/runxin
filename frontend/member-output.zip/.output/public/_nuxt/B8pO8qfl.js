import{d as a,o as s,a as t}from"./CGgrnszq.js";const e=a({__name:"template1",setup:a=>(a,e)=>(s(),t("div",null,"1111"))});export{e as default};
